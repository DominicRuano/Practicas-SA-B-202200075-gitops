{{- define "gateway.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- define "gateway.fullname" -}}
{{- if .Values.fullnameOverride }}{{ .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}{{ else }}{{ printf "%s-%s" .Release.Name (include "gateway.name" .) | trunc 63 | trimSuffix "-" }}{{ end }}
{{- end -}}
{{- define "gateway.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- define "gateway.selectorLabels" -}}
app.kubernetes.io/name: {{ include "gateway.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}
{{- define "gateway.labels" -}}
helm.sh/chart: {{ include "gateway.chart" . }}
{{ include "gateway.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: sa-platform
app.kubernetes.io/component: gateway
{{- end -}}
{{- define "gateway.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}{{ default (include "gateway.fullname" .) .Values.serviceAccount.name }}{{ else }}{{ default "default" .Values.serviceAccount.name }}{{ end }}
{{- end -}}
{{- define "gateway.image" -}}
{{- $registry := .Values.global.applicationImageRegistry | default .Values.image.registry -}}
{{- $repository := required "gateway.image.repository es obligatorio" .Values.image.repository -}}
{{- $tag := .Values.global.applicationImageTag | default .Values.image.tag | default .Chart.AppVersion -}}
{{- if $registry }}{{ printf "%s/%s:%s" $registry $repository $tag }}{{ else }}{{ printf "%s:%s" $repository $tag }}{{ end -}}
{{- end -}}
