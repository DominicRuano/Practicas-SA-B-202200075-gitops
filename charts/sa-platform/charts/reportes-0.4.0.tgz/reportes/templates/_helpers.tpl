{{- define "reportes.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- define "reportes.fullname" -}}
{{- if .Values.fullnameOverride }}{{ .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}{{ else }}{{ printf "%s-%s" .Release.Name (include "reportes.name" .) | trunc 63 | trimSuffix "-" }}{{ end }}
{{- end -}}
{{- define "reportes.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- define "reportes.selectorLabels" -}}
app.kubernetes.io/name: {{ include "reportes.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}
{{- define "reportes.labels" -}}
helm.sh/chart: {{ include "reportes.chart" . }}
{{ include "reportes.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: sa-platform
app.kubernetes.io/component: backend
{{- end -}}
{{- define "reportes.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}{{ default (include "reportes.fullname" .) .Values.serviceAccount.name }}{{ else }}{{ default "default" .Values.serviceAccount.name }}{{ end }}
{{- end -}}
{{- define "reportes.image" -}}
{{- $registry := .Values.global.applicationImageRegistry | default .Values.image.registry -}}
{{- $repository := required "reportes.image.repository es obligatorio" .Values.image.repository -}}
{{- $tag := .Values.global.applicationImageTag | default .Values.image.tag | default .Chart.AppVersion -}}
{{- if $registry }}{{ printf "%s/%s:%s" $registry $repository $tag }}{{ else }}{{ printf "%s:%s" $repository $tag }}{{ end -}}
{{- end -}}
