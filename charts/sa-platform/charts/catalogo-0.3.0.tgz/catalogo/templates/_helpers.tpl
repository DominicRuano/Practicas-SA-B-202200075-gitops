{{- define "catalogo.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- define "catalogo.fullname" -}}
{{- if .Values.fullnameOverride }}{{ .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}{{ else }}{{ printf "%s-%s" .Release.Name (include "catalogo.name" .) | trunc 63 | trimSuffix "-" }}{{ end }}
{{- end -}}
{{- define "catalogo.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- define "catalogo.selectorLabels" -}}
app.kubernetes.io/name: {{ include "catalogo.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}
{{- define "catalogo.labels" -}}
helm.sh/chart: {{ include "catalogo.chart" . }}
{{ include "catalogo.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: sa-platform
app.kubernetes.io/component: backend
{{- end -}}
{{- define "catalogo.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}{{ default (include "catalogo.fullname" .) .Values.serviceAccount.name }}{{ else }}{{ default "default" .Values.serviceAccount.name }}{{ end }}
{{- end -}}
{{- define "catalogo.image" -}}
{{- $registry := .Values.global.applicationImageRegistry | default .Values.image.registry -}}
{{- $repository := required "catalogo.image.repository es obligatorio" .Values.image.repository -}}
{{- $tag := .Values.global.applicationImageTag | default .Values.image.tag | default .Chart.AppVersion -}}
{{- if $registry }}{{ printf "%s/%s:%s" $registry $repository $tag }}{{ else }}{{ printf "%s:%s" $repository $tag }}{{ end -}}
{{- end -}}
