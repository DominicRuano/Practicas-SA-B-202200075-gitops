{{- define "autenticacion.name" -}}
{{- default .Chart.Name .Values.nameOverride | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- define "autenticacion.fullname" -}}
{{- if .Values.fullnameOverride }}{{ .Values.fullnameOverride | trunc 63 | trimSuffix "-" }}{{ else }}{{ printf "%s-%s" .Release.Name (include "autenticacion.name" .) | trunc 63 | trimSuffix "-" }}{{ end }}
{{- end -}}
{{- define "autenticacion.chart" -}}
{{- printf "%s-%s" .Chart.Name .Chart.Version | replace "+" "_" | trunc 63 | trimSuffix "-" -}}
{{- end -}}
{{- define "autenticacion.selectorLabels" -}}
app.kubernetes.io/name: {{ include "autenticacion.name" . }}
app.kubernetes.io/instance: {{ .Release.Name }}
{{- end -}}
{{- define "autenticacion.labels" -}}
helm.sh/chart: {{ include "autenticacion.chart" . }}
{{ include "autenticacion.selectorLabels" . }}
app.kubernetes.io/version: {{ .Chart.AppVersion | quote }}
app.kubernetes.io/managed-by: {{ .Release.Service }}
app.kubernetes.io/part-of: sa-platform
app.kubernetes.io/component: backend
{{- end -}}
{{- define "autenticacion.serviceAccountName" -}}
{{- if .Values.serviceAccount.create }}{{ default (include "autenticacion.fullname" .) .Values.serviceAccount.name }}{{ else }}{{ default "default" .Values.serviceAccount.name }}{{ end }}
{{- end -}}
{{- define "autenticacion.image" -}}
{{- $registry := .Values.global.applicationImageRegistry | default .Values.image.registry -}}
{{- $repository := required "autenticacion.image.repository es obligatorio" .Values.image.repository -}}
{{- $tag := .Values.global.applicationImageTag | default .Values.image.tag | default .Chart.AppVersion -}}
{{- if $registry }}{{ printf "%s/%s:%s" $registry $repository $tag }}{{ else }}{{ printf "%s:%s" $repository $tag }}{{ end -}}
{{- end -}}
